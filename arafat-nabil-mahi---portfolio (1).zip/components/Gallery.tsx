
import React from 'react';

const galleryImages = [
  { src: "C:\\Users\\iamas\\OneDrive\\Desktop\\New folder\\WhatsApp Image 2026-01-25 at 9.38.54 PM.jpeg", alt: "Event Capture 1" },
  { src: "C:\\Users\\iamas\\OneDrive\\Desktop\\New folder\\WhatsApp Image 2026-01-25 at 9.39.57 PM.jpeg", alt: "Event Capture 2" },
  { src: "C:\\Users\\iamas\\OneDrive\\Desktop\\New folder\\WhatsApp Image 2026-01-25 at 9.39.51 PM (1).jpeg", alt: "Volunteer Work" },
  { src: "C:\\Users\\iamas\\OneDrive\\Desktop\\New folder\\WhatsApp Image 2026-01-25 at 9.39.44 PM.jpeg", alt: "Scout Activities" },
  { src: "C:\\Users\\iamas\\OneDrive\\Desktop\\New folder\\WhatsApp Image 2026-01-25 at 9.39.43 PM.jpeg", alt: "Community Service" },
  { src: "C:\\Users\\iamas\\OneDrive\\Desktop\\New folder\\WhatsApp Image 2026-01-25 at 9.39.31 PM.jpeg", alt: "Team Meeting" },
  { src: "C:\\Users\\iamas\\OneDrive\\Desktop\\New folder\\WhatsApp Image 2026-01-25 at 9.39.30 PM.jpeg", alt: "Foundation Work" },
  { src: "C:\\Users\\iamas\\OneDrive\\Desktop\\Scout\\Boyez uddin pics\\483183741_1306899437080590_4573261440297629427_n.jpg", alt: "Boyez Uddin Open Scout Group" },
  { src: "C:\\Users\\iamas\\Downloads\\Untitled design (3).jpg", alt: "Achievement Showcase" }
];

const Gallery: React.FC = () => {
  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold text-slate-900 dark:text-white">Gallery</h2>
        <p className="text-slate-500 dark:text-slate-400 mt-2">Captured moments from various social and educational events.</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {galleryImages.map((img, idx) => (
          <div key={idx} className="group relative aspect-square overflow-hidden rounded-2xl bg-slate-200 dark:bg-slate-800/50">
            <img 
              src={img.src} 
              alt={img.alt}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              onError={(e) => {
                // Fallback for local files if they can't be loaded
                (e.target as HTMLImageElement).src = `https://picsum.photos/seed/gallery${idx}/800/800`;
              }}
            />
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center p-4">
              <span className="text-white text-sm font-medium text-center">{img.alt}</span>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Gallery;
