
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 text-slate-400 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="mb-6 flex justify-center">
          <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-slate-700">
            <img 
              src="C:\Users\iamas\Downloads\untitled (3).jpg.jpg" 
              alt="Logo"
              className="w-full h-full object-cover"
              onError={(e) => {
                (e.target as HTMLImageElement).src = 'https://api.dicebear.com/7.x/avataaars/svg?seed=Arafat';
              }}
            />
          </div>
        </div>
        <p className="text-sm max-w-md mx-auto mb-8">
          Self-motivated and dedicated, contributing to the scientific and social development of Bangladesh.
        </p>
        <div className="border-t border-slate-800 pt-8">
          <p className="text-xs uppercase tracking-widest font-semibold">
            &copy; {new Date().getFullYear()} All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
