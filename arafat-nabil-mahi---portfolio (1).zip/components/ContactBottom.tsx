
import React, { useState } from 'react';

const ContactBottom: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState('');

  const toggleContact = () => {
    setIsOpen(!isOpen);
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    // Standard WhatsApp redirect to deliver the message to the specified number
    // Format: 880 (Country Code) + 1410490470 (Number without leading 0)
    const phoneNumber = "8801410490470";
    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodedMessage}`;
    
    window.open(whatsappUrl, '_blank');
    setMessage('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
      <style>{`
        @keyframes balloon-float {
          0%, 100% { 
            transform: translateY(0) scale(1, 1); 
            filter: drop-shadow(0 5px 15px rgba(0, 212, 255, 0.2));
          }
          50% { 
            transform: translateY(-12px) scale(1.03, 0.97); 
            filter: drop-shadow(0 20px 25px rgba(0, 212, 255, 0.4));
          }
        }
        .animate-balloon {
          display: inline-flex;
          animation: balloon-float 4s ease-in-out infinite;
        }
      `}</style>

      <div className="flex flex-col items-center gap-8">
        {/* Toggle Button for Contact Details */}
        <button
          onClick={toggleContact}
          className="group relative inline-flex items-center gap-3 px-10 py-5 bg-indigo-600 dark:bg-[#00d4ff] text-white dark:text-slate-900 rounded-full font-extrabold text-2xl transition-all hover:brightness-110 hover:scale-105 active:scale-95 shadow-xl shadow-indigo-200 dark:shadow-cyan-900/30"
        >
          <span>Contact Me</span>
          <svg 
            className={`w-7 h-7 transition-transform duration-500 ${isOpen ? 'rotate-180' : ''}`} 
            fill="none" 
            viewBox="0 0 24 24" 
            stroke="currentColor"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M19 9l-7 7-7-7" />
          </svg>
        </button>

        {/* Expandable Contact Details Grid */}
        <div 
          className={`w-full overflow-hidden transition-all duration-700 ease-in-out ${
            isOpen ? 'max-h-[2000px] opacity-100 mt-8' : 'max-h-0 opacity-0'
          }`}
        >
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-8 bg-slate-50 dark:bg-slate-800/40 rounded-[3rem] border border-slate-200 dark:border-slate-700 transition-colors shadow-inner">
            
            {/* Phone */}
            <div className="flex flex-col items-center p-6 bg-white dark:bg-slate-800 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-700 hover:scale-105 transition-transform">
              <div className="w-14 h-14 bg-green-50 dark:bg-green-900/20 rounded-2xl flex items-center justify-center text-green-600 dark:text-green-400 mb-4">
                <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                </svg>
              </div>
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Phone</h4>
              <a href="tel:01410490470" className="text-slate-900 dark:text-white font-bold text-lg hover:text-[#00d4ff] transition-colors">01410490470</a>
            </div>

            {/* Email */}
            <div className="flex flex-col items-center p-6 bg-white dark:bg-slate-800 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-700 hover:scale-105 transition-transform">
              <div className="w-14 h-14 bg-blue-50 dark:bg-blue-900/20 rounded-2xl flex items-center justify-center text-blue-600 dark:text-blue-400 mb-4">
                <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
              </div>
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Email</h4>
              <a href="mailto:afatnabilmahi12@gmail.com" className="text-slate-900 dark:text-white font-bold text-lg hover:text-[#00d4ff] transition-colors break-all">afatnabilmahi12@gmail.com</a>
            </div>

            {/* Facebook */}
            <a 
              href="https://www.facebook.com/arafatnabil.official" 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex flex-col items-center p-6 bg-white dark:bg-slate-800 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-700 hover:scale-105 transition-transform"
            >
              <div className="w-14 h-14 bg-indigo-50 dark:bg-indigo-900/20 rounded-2xl flex items-center justify-center text-indigo-600 dark:text-indigo-400 mb-4">
                <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z" />
                </svg>
              </div>
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Facebook</h4>
              <span className="text-slate-900 dark:text-white font-bold text-lg group-hover:text-[#00d4ff]">arafatnabil.official</span>
            </a>

            {/* LinkedIn */}
            <a 
              href="https://www.linkedin.com/in/arafat-nabil-" 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex flex-col items-center p-6 bg-white dark:bg-slate-800 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-700 hover:scale-105 transition-transform"
            >
              <div className="w-14 h-14 bg-sky-50 dark:bg-sky-900/20 rounded-2xl flex items-center justify-center text-sky-600 dark:text-sky-400 mb-4">
                <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z" />
                </svg>
              </div>
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">LinkedIn</h4>
              <span className="text-slate-900 dark:text-white font-bold text-lg group-hover:text-[#00d4ff]">arafat-nabil</span>
            </a>

            {/* Present Address */}
            <div className="flex flex-col items-center p-6 bg-white dark:bg-slate-800 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-700 hover:scale-105 transition-transform lg:col-span-2">
              <div className="w-14 h-14 bg-rose-50 dark:bg-rose-900/20 rounded-2xl flex items-center justify-center text-rose-600 dark:text-rose-400 mb-4">
                <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
              </div>
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Address</h4>
              <p className="text-slate-900 dark:text-white font-bold text-lg text-center leading-relaxed max-w-md">
                Sr Lane, North Katnar Para, Bogura - 5800 <br/>
                <span className="text-sm font-medium text-slate-500">Permanent: Joypurhat - 5910, Bangladesh</span>
              </p>
            </div>
          </div>
        </div>

        {/* Persistent Message Box with Balloon Animation */}
        <div className="w-full mt-12 bg-white dark:bg-[#112240] p-8 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-2xl transition-all max-w-4xl mx-auto">
          <div className="mb-10">
            <h3 className="text-4xl font-black text-slate-900 dark:text-white flex items-center justify-center gap-4 animate-balloon">
              <span className="w-14 h-14 bg-[#00d4ff] text-slate-900 rounded-2xl flex items-center justify-center shadow-xl shadow-cyan-500/40 rotate-3">
                <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                </svg>
              </span>
              <span className="bg-gradient-to-r from-slate-900 to-slate-700 dark:from-white dark:to-slate-300 bg-clip-text text-transparent uppercase tracking-tight">
                Send us message
              </span>
            </h3>
          </div>
          
          <form onSubmit={handleSendMessage} className="space-y-6">
            <div className="relative group">
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Type your message for Arafat here..."
                className="w-full min-h-[200px] p-8 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-[2rem] text-slate-900 dark:text-white placeholder-slate-400 focus:ring-4 focus:ring-[#00d4ff]/20 focus:border-[#00d4ff] outline-none transition-all resize-none shadow-inner text-lg font-medium"
                required
              />
              <div className="absolute top-6 right-6 text-slate-300 dark:text-slate-600 pointer-events-none opacity-50">
                <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                </svg>
              </div>
            </div>

            <button
              type="submit"
              className="w-full group flex items-center justify-center gap-4 px-10 py-5 bg-[#00d4ff] text-slate-900 font-black text-xl rounded-[2rem] hover:brightness-110 hover:shadow-[0_0_30px_rgba(0,212,255,0.5)] active:scale-[0.97] transition-all shadow-xl"
            >
              <span>SEND TO WHATSAPP</span>
              <svg className="w-7 h-7 group-hover:translate-x-2 group-hover:-translate-y-2 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
              </svg>
            </button>
            <div className="flex items-center justify-center gap-2 text-slate-400 dark:text-slate-500 font-bold uppercase tracking-widest text-xs">
              <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
              Direct Delivery to 01410490470
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ContactBottom;
