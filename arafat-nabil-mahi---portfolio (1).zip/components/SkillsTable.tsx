
import React from 'react';

// Simplified SVG components for the logos
const SoftwareIcon = ({ name }: { name: string }) => {
  const size = "w-5 h-5";
  switch (name) {
    case "Adobe Illustrator":
      return <div className={`${size} bg-[#FF9A00] rounded-sm flex items-center justify-center text-[10px] font-bold text-black`}>Ai</div>;
    case "Adobe Photoshop":
      return <div className={`${size} bg-[#31A8FF] rounded-sm flex items-center justify-center text-[10px] font-bold text-black`}>Ps</div>;
    case "MS Word":
      return <div className={`${size} bg-[#2B579A] rounded-sm flex items-center justify-center text-[10px] font-bold text-white`}>W</div>;
    case "Excel":
      return <div className={`${size} bg-[#217346] rounded-sm flex items-center justify-center text-[10px] font-bold text-white`}>X</div>;
    case "Powerpoint":
      return <div className={`${size} bg-[#D24726] rounded-sm flex items-center justify-center text-[10px] font-bold text-white`}>P</div>;
    case "Canva":
      return <div className={`${size} bg-gradient-to-br from-[#00C4CC] to-[#7D2AE8] rounded-full flex items-center justify-center text-[8px] font-bold text-white`}>C</div>;
    case "Google Forms":
      return <div className={`${size} bg-[#673AB7] rounded-sm flex items-center justify-center text-[10px] font-bold text-white`}>F</div>;
    case "Survey heart":
      return <div className={`${size} bg-rose-500 rounded-sm flex items-center justify-center text-white`}>
        <svg viewBox="0 0 24 24" fill="currentColor" className="w-3 h-3"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
      </div>;
    default:
      return <div className={`${size} bg-slate-200 rounded-sm`} />;
  }
};

const ProIcon = ({ name }: { name: string }) => {
  const size = "w-5 h-5 text-[#00d4ff]";
  switch (name) {
    case "Leadership":
      return <svg className={size} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>;
    case "Teamwork":
      return <svg className={size} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg>;
    case "Management":
      return <svg className={size} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01m-.01 4h.01" /></svg>;
    case "Hardworker":
      return <svg className={size} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>;
    case "Problem Solving":
      return <svg className={size} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 4a2 2 0 114 0v1a1 1 0 001 1h3a1 1 0 011 1v3a1 1 0 01-1 1h-1a2 2 0 100 4h1a1 1 0 011 1v3a1 1 0 01-1 1h-3a1 1 0 01-1-1v-1a2 2 0 10-4 0v1a1 1 0 01-1 1H7a1 1 0 01-1-1v-3a1 1 0 011-1h1a2 2 0 100-4H7a1 1 0 01-1-1V7a1 1 0 011-1h3a1 1 0 001-1V4z" /></svg>;
    case "Strong Work Ethic":
      return <svg className={size} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;
    case "Public Speaking":
      return <svg className={size} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>;
    case "Communication":
      return <svg className={size} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>;
    default:
      return <div className={size} />;
  }
};

const SkillsTable: React.FC = () => {
  const softwareSkills = [
    "Adobe Illustrator", "MS Word", "Excel", "Survey heart",
    "Powerpoint", "Google Forms", "Canva", "Adobe Photoshop"
  ];

  const professionalSkills = [
    "Leadership", "Teamwork", "Management", "Hardworker",
    "Problem Solving", "Strong Work Ethic", "Public Speaking", "Communication"
  ];

  const rowCount = Math.max(softwareSkills.length, professionalSkills.length);

  return (
    <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold text-slate-900 dark:text-white">Professional Skills</h2>
        <p className="text-slate-500 dark:text-slate-400 mt-2 italic">A visually enriched summary of my skill sets.</p>
      </div>

      <div className="overflow-hidden border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm bg-white dark:bg-[#112240] transition-colors duration-300">
        <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-800">
          <thead className="bg-slate-50 dark:bg-slate-800/50">
            <tr>
              <th scope="col" className="px-6 py-4 text-left text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider border-r border-slate-200 dark:border-slate-800">
                Computer & Software Skills
              </th>
              <th scope="col" className="px-6 py-4 text-left text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                Professional & Leadership Skills
              </th>
            </tr>
          </thead>
          <tbody className="bg-white dark:bg-transparent divide-y divide-slate-200 dark:divide-slate-800">
            {Array.from({ length: rowCount }).map((_, i) => (
              <tr key={i} className="hover:bg-slate-50 dark:hover:bg-white/5 transition-colors">
                <td className="px-6 py-4 whitespace-nowrap border-r border-slate-200 dark:border-slate-800">
                  {softwareSkills[i] && (
                    <div className="flex items-center gap-3">
                      <SoftwareIcon name={softwareSkills[i]} />
                      <span className="text-sm text-slate-700 dark:text-slate-300 font-medium">{softwareSkills[i]}</span>
                    </div>
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {professionalSkills[i] && (
                    <div className="flex items-center gap-3">
                      <ProIcon name={professionalSkills[i]} />
                      <span className="text-sm text-slate-700 dark:text-slate-300 font-medium">{professionalSkills[i]}</span>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
};

export default SkillsTable;
