
import React, { useState, useEffect } from 'react';

const dreamWheelsImages = [
  "C:\\Users\\iamas\\Downloads\\Dream Wheels\\1.jpg",
  "C:\\Users\\iamas\\Downloads\\Dream Wheels\\2.jpg",
  "C:\\Users\\iamas\\Downloads\\Dream Wheels\\3.jpg",
  "C:\\Users\\iamas\\Downloads\\Dream Wheels\\4.jpg",
  "C:\\Users\\iamas\\Downloads\\Dream Wheels\\5.jpg",
  "C:\\Users\\iamas\\Downloads\\Dream Wheels\\6.jpg",
  "C:\\Users\\iamas\\Downloads\\Dream Wheels\\7.jpg",
  "C:\\Users\\iamas\\Downloads\\Dream Wheels\\8.jpg",
  "C:\\Users\\iamas\\Downloads\\Dream Wheels\\9.jpg",
  "C:\\Users\\iamas\\Downloads\\Dream Wheels\\10.jpg",
];

const achievementsData = [
  { text: "President’s Scout Award – 2023", emoji: "🏆" },
  { text: "IAAC International Qualification", emoji: "🌍" },
  { text: "Runner Up – IWC Bangladesh 2026", emoji: "🥈" },
  { text: "Qualified for IWC Indonesia", emoji: "✈️" },
  { text: "Government Stipend Awardee in 2025", emoji: "🎓" }
];

const BlogAndAchievements: React.FC = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % dreamWheelsImages.length);
    }, 3000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="flex flex-col lg:flex-row gap-12">
        {/* Blog Section */}
        <div className="lg:w-1/2">
          <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-6">Blog</h2>
          <div className="bg-slate-50 dark:bg-slate-800/40 p-6 rounded-3xl border border-slate-200 dark:border-slate-700 transition-colors">
            <h3 className="text-xl font-bold text-[#00d4ff] mb-4">Dream Wheels</h3>
            
            {/* Slideshow */}
            <div className="relative aspect-video overflow-hidden rounded-2xl bg-slate-200 dark:bg-slate-900 shadow-inner">
              {dreamWheelsImages.map((img, idx) => (
                <div
                  key={idx}
                  className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
                    idx === currentSlide ? 'opacity-100' : 'opacity-0'
                  }`}
                >
                  <img
                    src={img}
                    alt={`Dream Wheels ${idx + 1}`}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = `https://picsum.photos/seed/dw${idx}/800/600`;
                    }}
                  />
                  <div className="absolute bottom-4 right-4 bg-black/50 text-white text-xs px-3 py-1 rounded-full backdrop-blur-sm">
                    {idx + 1} / {dreamWheelsImages.length}
                  </div>
                </div>
              ))}
            </div>
            <p className="mt-4 text-slate-600 dark:text-slate-400 text-sm leading-relaxed">
              Explore the "Dream Wheels" collection - a curated selection of engineering marvels and automotive inspirations.
            </p>
          </div>
        </div>

        {/* Achievements Section */}
        <div className="lg:w-1/2">
          <div className="bg-[#111827] dark:bg-black/40 p-8 rounded-3xl shadow-xl min-h-full border border-slate-800/50">
            <h2 className="text-4xl font-bold text-[#00d4ff] mb-10 tracking-tight">Achievements</h2>
            
            <div className="relative border-l-4 border-[#00d4ff] ml-2 pl-8 space-y-8">
              {achievementsData.map((item, idx) => (
                <div 
                  key={idx} 
                  className="flex items-center gap-4 group transition-transform duration-300 hover:translate-x-2"
                >
                  <span className="text-2xl flex-shrink-0" role="img" aria-label="achievement-icon">
                    {item.emoji}
                  </span>
                  <p className="text-white font-medium text-xl leading-snug">
                    {item.text}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BlogAndAchievements;
