
import React, { useState, useEffect } from 'react';

const Hero: React.FC = () => {
  const roles = ["Developer", "Public Speaker", "Innovator", "Designer", "Student", "Volunteer"];
  const [index, setIndex] = useState(0);
  const [subIndex, setSubIndex] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);

  // Typing effect logic
  useEffect(() => {
    if (subIndex === roles[index].length + 1 && !isDeleting) {
      const timeout2 = setTimeout(() => setIsDeleting(true), 2000);
      return () => clearTimeout(timeout2);
    }

    if (subIndex === 0 && isDeleting) {
      setIsDeleting(false);
      setIndex((prev) => (prev + 1) % roles.length);
      return;
    }

    const timeout = setTimeout(() => {
      setSubIndex((prev) => prev + (isDeleting ? -1 : 1));
    }, isDeleting ? 70 : 150);

    return () => clearTimeout(timeout);
  }, [subIndex, index, isDeleting, roles]);

  return (
    <section className="relative py-12 lg:py-20 overflow-hidden bg-[#0a192f] text-white">
      {/* Subtle grid pattern background */}
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10 pointer-events-none" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col md:flex-row items-center justify-between min-h-[300px] gap-8">
          
          {/* Empty spacer for left side on desktop to help center the text */}
          <div className="hidden md:block w-32 lg:w-48"></div>

          {/* Centered Name and Role with Animation */}
          <div className="flex-1 text-center">
            <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight text-white uppercase mb-4">
              ARAFAT NABIL MAHI
            </h1>
            <div className="h-10 flex justify-center items-center">
              <p className="text-xl md:text-2xl font-bold text-[#00d4ff] tracking-widest uppercase border-r-2 border-[#00d4ff] pr-1 animate-pulse-cursor min-h-[1.2em]">
                {roles[index].substring(0, subIndex)}
              </p>
            </div>
          </div>

          {/* Right-aligned Profile Picture with Cyan Ring */}
          <div className="flex-shrink-0">
            <div className="relative">
              <div className="w-32 h-32 md:w-44 md:h-44 lg:w-52 lg:h-52 rounded-full overflow-hidden border-4 border-slate-900 ring-4 ring-[#00d4ff] shadow-[0_0_20px_rgba(0,212,255,0.3)]">
                <img 
                  src="C:\Users\iamas\OneDrive\Desktop\Untitled design (1).jpg" 
                  alt="Arafat Nabil Mahi"
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = 'https://api.dicebear.com/7.x/avataaars/svg?seed=Arafat';
                  }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* About Me and Academic Info - Integrated below the main banner */}
        <div className="mt-16 pt-16 border-t border-white/5">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6 text-slate-300 text-lg leading-relaxed">
              <p>
                As a dedicated student and tech-loving innovator, I am always passionate about learning and creating something new. 
                With the courage of an entrepreneur and the compassion of a volunteer, I am working towards building a beautiful, 
                science-minded society. I firmly believe that the right use of technology can truly transform our lives.
              </p>
              <div className="flex items-start gap-4 p-5 bg-white/5 rounded-2xl border-l-4 border-[#00d4ff]">
                <span className="text-4xl text-[#00d4ff] font-serif">"</span>
                <p className="font-medium text-white italic mt-2">
                  Humans are for humanity, and life is for living—can a human not expect a little empathy? Let us strive to live for others, just as we live for ourselves.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-1 gap-4">
              <div className="p-4 bg-slate-800/40 rounded-xl border border-slate-700">
                <h3 className="text-[#00d4ff] font-bold text-xs uppercase tracking-widest mb-1">Studying HSC</h3>
                <p className="text-white font-bold text-sm">Govt Azizul Haque College, Bogura</p>
              </div>
              <div className="p-4 bg-slate-800/40 rounded-xl border border-slate-700">
                <h3 className="text-[#00d4ff] font-bold text-xs uppercase tracking-widest mb-1">SSC - Science</h3>
                <p className="text-white font-bold text-sm">Ramdeo Bazla Govt High • GPA 5.00</p>
              </div>
              <div className="p-4 bg-slate-800/40 rounded-xl border border-slate-700">
                <h3 className="text-[#00d4ff] font-bold text-xs uppercase tracking-widest mb-1">PEC</h3>
                <p className="text-white font-bold text-sm">Biam Model School • GPA 5.00</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <style>{`
        @keyframes blink {
          50% { border-color: transparent; }
        }
        .animate-pulse-cursor {
          animation: blink 0.8s step-end infinite;
        }
      `}</style>
    </section>
  );
};

export default Hero;
