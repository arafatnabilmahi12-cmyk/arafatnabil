
import React from 'react';

interface HeaderProps {
  onContactClick: () => void;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
}

const Header: React.FC<HeaderProps> = ({ onContactClick, isDarkMode, toggleDarkMode }) => {
  return (
    <header className="sticky top-0 z-40 w-full bg-white/80 dark:bg-[#0a192f]/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center gap-4">
            {/* Dark/Light Mode Converter - Styled like screenshot */}
            <button 
              onClick={toggleDarkMode}
              className="w-10 h-10 bg-[#00d4ff] rounded-xl flex items-center justify-center shadow-lg hover:brightness-110 transition-all active:scale-90 overflow-hidden group"
              title={isDarkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
            >
              {isDarkMode ? (
                // Sun Icon
                <svg className="w-6 h-6 text-yellow-100" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.343 17.657l-.707.707m12.728 0l-.707-.707M6.343 6.343l-.707-.707M12 8a4 4 0 100 8 4 4 0 000-8z" />
                </svg>
              ) : (
                // Moon Icon matching the screenshot visual
                <svg className="w-6 h-6 text-yellow-400 drop-shadow-sm group-hover:rotate-12 transition-transform" viewBox="0 0 24 24" fill="currentColor">
                   <path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z" />
                </svg>
              )}
            </button>

            {/* Logo */}
            <div 
              className="relative group cursor-pointer" 
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            >
              <img 
                src="C:\Users\iamas\Downloads\untitled (3).jpg.jpg" 
                alt="Logo"
                className="w-10 h-10 rounded-full object-cover border-2 border-[#00d4ff] shadow-sm transition-transform duration-300 group-hover:scale-110"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = 'https://api.dicebear.com/7.x/avataaars/svg?seed=Arafat';
                }}
              />
            </div>
          </div>

          <nav className="hidden md:flex space-x-8 text-sm font-medium text-slate-600 dark:text-slate-400">
            <a href="#experience" className="hover:text-[#00d4ff] transition-colors">Experience</a>
            <a href="#skills" className="hover:text-[#00d4ff] transition-colors">Skills</a>
            <a href="#blog-achievements" className="hover:text-[#00d4ff] transition-colors">Achievements</a>
            <a href="#gallery" className="hover:text-[#00d4ff] transition-colors">Gallery</a>
          </nav>

          <div className="flex items-center gap-4">
            <button 
              onClick={onContactClick}
              className="px-4 py-2 bg-indigo-600 dark:bg-[#00d4ff] dark:text-slate-900 text-white text-xs font-bold rounded-full hover:brightness-110 transition-all active:scale-95 shadow-sm"
            >
              CONTACT ME
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
