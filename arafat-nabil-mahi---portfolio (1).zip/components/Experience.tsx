
import React from 'react';

const experiences = [
  {
    role: "Senior Patrol Leader",
    org: "Boyez Uddin Ahmed Open Scout Group, Joypurhat",
    period: "2023 - Present",
    desc: "The experience and skills achieved from Bangladesh Scouts helped me to improve my public speaking and work management skills."
  },
  {
    role: "Cadet",
    org: "Govt Azizul Haque College BNCC Platoon",
    period: "Active",
    desc: "Developing discipline, leadership, and national service values through Bangladesh National Cadet Corps training."
  },
  {
    role: "National Affairs & Networking Secretary",
    org: "Re Earth Foundation",
    period: "Active",
    desc: "Maintaining a healthy connection with everyone, I improved my communication skills."
  },
  {
    role: "Chief Campus Ambassador",
    org: "NUVORA",
    period: "Active",
    desc: "Working with my fellow club mates in different events & publications, I improved my teamwork ability and developed a strong work ethic."
  },
  {
    role: "Member",
    org: "VBD Panchbibi Upazila",
    period: "2025 - Present",
    desc: "VBD gave me lots of opportunities to learn & improve my leadership and communication skills."
  },
  {
    role: "Active Member",
    org: "BD Clean Organization",
    period: "2023 - Present",
    desc: "Contributing to environmental awareness and clean-up initiatives across the region."
  },
  {
    role: "Active Member",
    org: "Rongdhonu Social Service Organization",
    period: "2020 - Present",
    desc: "Dedicated to social welfare and community support programs."
  }
];

const Experience: React.FC = () => {
  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold text-slate-900 dark:text-white sm:text-4xl uppercase tracking-tight">Experience</h2>
        <div className="mt-4 w-20 h-1 bg-[#00d4ff] mx-auto rounded-full" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {experiences.map((exp, idx) => (
          <div key={idx} className="flex flex-col p-6 bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 rounded-2xl hover:shadow-lg transition-all duration-300">
            <span className="text-[#00d4ff] text-xs font-bold uppercase tracking-widest mb-2">{exp.period}</span>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-1">{exp.role}</h3>
            <p className="text-[#00d4ff] font-semibold text-sm mb-4">{exp.org}</p>
            <p className="text-slate-600 dark:text-slate-400 text-sm leading-relaxed">{exp.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Experience;
